package Pizzarron;
import Pizzarron.gui.VentanaPizarron;

public class Main {
    public static void main(String[] args) {

        VentanaPizarron pizarron = new VentanaPizarron();

    }
}