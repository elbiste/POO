package Pizzarron.exception;

public class DrawingException extends Exception {
    private static final long serialVersionUID = 1l;
}
