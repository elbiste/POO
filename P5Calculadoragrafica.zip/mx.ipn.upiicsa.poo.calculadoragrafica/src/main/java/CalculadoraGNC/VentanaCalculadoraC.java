package CalculadoraGNC;

import javax.swing.*;
import java.awt.*;

public class VentanaCalculadoraC extends JFrame {
    private JTextField display;
    private JButton button0;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton button6;
    private JButton button7;
    private JButton button8;
    private JButton button9;
    private JButton buttonPunto;
    private JButton buttonLimpiar;
    private JButton buttonPiso;
    private JButton buttonTecho;
    private JButton buttonRedondeo;
    private JButton buttonPotencia2;
    private JButton buttonPotencia3;
    private JButton buttonPotenciaN;
    private JButton buttonRaiz2;
    private JButton buttonRaiz3;
    private JButton buttonRaizN;
    private JButton buttonSeno;
    private JButton buttonCoseno;
    private JButton buttonTangente;
    private JButton buttonFactorial;


    public VentanaCalculadoraC(){
        initComponents();
    }
    private void initComponents(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(500,500);
        setResizable(false);
        button0 = new JButton("O");
        button1 = new JButton("1");
        button2 = new JButton("2");
        button3 = new JButton("3");
        button4 = new JButton("4");
        button5 = new JButton("5");
        button6 = new JButton("6");
        button7 = new JButton("7");
        button8 = new JButton("8");
        button9 = new JButton("9");
        buttonPunto = new JButton(".");
        buttonLimpiar = new JButton("AC");
        buttonPiso = new JButton("pi");
        buttonTecho = new JButton("t");
        buttonRedondeo = new JButton("re");
        buttonPotencia2 = new JButton("x^2");
        buttonPotencia3 = new JButton("x^3");
        buttonPotenciaN = new JButton("x^n");
        buttonRaiz2 = new JButton("x_2");
        buttonRaiz3 = new JButton("x_3");
        buttonRaizN = new JButton("x_n");
        buttonSeno = new JButton("sin");
        buttonCoseno = new JButton("cos");
        buttonTangente = new JButton("tan");
        buttonFactorial = new JButton("x!");

        Container pane = getContentPane();
        GridBagLayout calculadoracGrid = new GridBagLayout();
        GridBagConstraints calculadoracGridConstrainsts = new GridBagConstraints();
        pane.setLayout(calculadoracGrid);

        calculadoracGridConstrainsts.fill = GridBagConstraints.HORIZONTAL;
        calculadoracGridConstrainsts.gridx = 0;
        calculadoracGridConstrainsts.gridy = 0;
        calculadoracGridConstrainsts.gridwidth = 4;
        pane.add(display,calculadoracGridConstrainsts);


        calculadoracGridConstrainsts.gridx = 0;
        calculadoracGridConstrainsts.gridy = 1;
        pane.add(buttonRaiz2,calculadoracGridConstrainsts);

        calculadoracGridConstrainsts.gridx = 1;
        calculadoracGridConstrainsts.gridy = 1;
        pane.add(buttonLimpiar, calculadoracGridConstrainsts);

        calculadoracGridConstrainsts.gridx = 2;
        calculadoracGridConstrainsts.gridy = 1;
        pane.add(buttonPotencia2, calculadoracGridConstrainsts);

        calculadoracGridConstrainsts.gridx = 3;
        calculadoracGridConstrainsts.gridy = 1;
        pane.add(buttonFactorial, calculadoracGridConstrainsts);

        calculadoracGridConstrainsts.gridx = 4;
        calculadoracGridConstrainsts.gridy = 1;
        pane.add(buttonSeno, calculadoracGridConstrainsts);

        setVisible(true);

    }

}
