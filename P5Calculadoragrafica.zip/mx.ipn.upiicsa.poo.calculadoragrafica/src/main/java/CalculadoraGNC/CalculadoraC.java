package CalculadoraGNC;

import java.math.MathContext;
public class CalculadoraC {
    public double piso(double a) {
        return Math.floor(a);
    }
    public  double techo(double a){
        return Math.ceil(a);
    }

    public double redondeo(double a){
        return Math.round(a);
    }

    public double potencia(double a){
        return Math.pow(a,2);
    }

    public double potenciacubo(double a){
        return Math.pow(a,3);
    }
}
