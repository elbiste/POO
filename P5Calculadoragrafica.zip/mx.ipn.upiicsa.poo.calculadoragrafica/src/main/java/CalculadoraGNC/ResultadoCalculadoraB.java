package CalculadoraGNC;

import java.awt.event.ActionListener;

public class ResultadoCalculadoraB {

    public static int SET_VALUE=1;
    public static int ADD_VALUE =2;
    public static int SET_CLEAR=3;
    public static int SET_CLEAR_AND_ADD=4;

    boolean valid;
    int displayAction;
    String resultado;

    public ResultadoCalculadoraB() {
        this.valid = true;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public int getDisplayAction() {
        return displayAction;
    }

    public void setDisplayAction(int displayAction) {
        this.displayAction = displayAction;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
}
