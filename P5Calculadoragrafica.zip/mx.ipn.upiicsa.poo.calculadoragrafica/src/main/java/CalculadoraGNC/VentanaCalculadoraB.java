package CalculadoraGNC;

import javax.swing.*;
import java.awt.*;

public class VentanaCalculadoraB extends JFrame {
    private JTextField display;
    private JButton button0;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton button6;
    private JButton button7;
    private JButton button8;
    private JButton button9;
    private JButton buttonPunto;
    private JButton buttonLimpiar;
    private JButton buttonPorcentaje;
    private JButton buttonDivision;
    private JButton buttonProducto;
    private JButton buttonSuma;
    private JButton buttonResta;
    private JButton buttonResultado;

    public VentanaCalculadoraB(){
        initComponents();
    }
    private void initComponents(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(500,500);
        setResizable(false);
        display = new JTextField("");
        button0 = new JButton("O");
        button1 = new JButton("1");
        button2 = new JButton("2");
        button3 = new JButton("3");
        button4 = new JButton("4");
        button5 = new JButton("5");
        button6 = new JButton("6");
        button7 = new JButton("7");
        button8 = new JButton("8");
        button9 = new JButton("9");
        buttonPunto = new JButton(".");
        buttonLimpiar = new JButton("AC");
        buttonPorcentaje = new JButton("%");
        buttonDivision = new JButton("/") ;
        buttonProducto = new JButton("x");
        buttonSuma = new JButton("+");
        buttonResta = new JButton("-");
        buttonResultado = new JButton("=");

        Container pane = getContentPane();
        GridBagLayout calculadorabGrid = new GridBagLayout();
        GridBagConstraints calculadorabGridConstrainsts = new GridBagConstraints();
        pane.setLayout(calculadorabGrid);

        calculadorabGridConstrainsts.fill = GridBagConstraints.HORIZONTAL;
        calculadorabGridConstrainsts.gridx = 0;
        calculadorabGridConstrainsts.gridy = 0;
        calculadorabGridConstrainsts.gridwidth = 4;
        pane.add(display,calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 0;
        calculadorabGridConstrainsts.gridy = 1;
        pane.add(buttonPorcentaje,calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 1;
        calculadorabGridConstrainsts.gridy = 1;
        pane.add(buttonLimpiar, calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 2;
        calculadorabGridConstrainsts.gridy = 1;
        pane.add(buttonProducto, calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 3;
        calculadorabGridConstrainsts.gridy = 1;
        pane.add(buttonDivision, calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 0;
        calculadorabGridConstrainsts.gridy = 2;
        pane.add(button7,calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 1;
        calculadorabGridConstrainsts.gridy = 2;
        pane.add(buttonLimpiar, calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 2;
        calculadorabGridConstrainsts.gridy = 1;
        pane.add(buttonProducto, calculadorabGridConstrainsts);

        calculadorabGridConstrainsts.gridx = 3;
        calculadorabGridConstrainsts.gridy = 1;
        pane.add(buttonDivision, calculadorabGridConstrainsts);

        setVisible(true);
    }

}
