package CalculadoraGNC;

public class CalculadoraB {
    public double suma(double a, double b) {
        return a+b;
    }

    public double resta(double a, double b) {
        return a-b;
    }

    public double multiplicacion(double a, double b) {
        return a*b;
    }

    public double division(double a, double b) {
        if(b==0) {
            throw new RuntimeException("Div Zero");
        }
        return a/b;
    }

    public double porcentaje(double a, double b) {
        return (a/100)*b;
    }
}
