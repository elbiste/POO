package CalculadoraGNC;

import java.util.Locale;

public class App {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        String opcion = "-p, -m, -g1 , g2";
        System.out.println("Ingresa la opcion que deseas: ");
        System.out.println("Calculadora (-g1) ");
        System.out.println("2. Calculadora Cientifica (-g2)");
            switch (opcion){
                case "-g1":
                    VentanaCalculadoraB ventanaCalculadora = new VentanaCalculadoraB();
                case "-g2":
                    VentanaCalculadoraC ventanaCalculadoraC = new VentanaCalculadoraC();
            }
        }

    }