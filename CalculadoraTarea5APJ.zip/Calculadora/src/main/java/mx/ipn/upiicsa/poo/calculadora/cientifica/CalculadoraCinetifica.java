package mx.ipn.upiicsa.poo.calculadora.cientifica;

import mx.ipn.upiicsa.poo.calculadora.App;
import mx.ipn.upiicsa.poo.calculadora.cientifica.CalculadoraCientifcaOperadores;
import mx.ipn.upiicsa.poo.calculadora.cientifica.ModoOperacion;
import java.math.MathContext;

import java.util.Scanner;

public class CalculadoraCinetifica  extends App{
    public static void main(String[] args) {
    Scanner user_input = new Scanner(System.in);
    double piso, techo, redondeo, potencia2, potencia3, potencian, raiz2, raiz3, raizn, seno, coseno, tan, fasct, num1, num2;
    CalculadoraCientifcaOperadores calculadoraCientifcaOperadores = CalculadoraCientifcaOperadores.valueOf(user_input.next());
    switch(calculadoraCientifcaOperadores){
        case PISO:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            piso = Math.floor(num1);
            System.out.println("El rendondeo al entero mayor: "+ piso);
        case TECHO:
            System.out.println("Ingresa el numero");
            num1 = user_input.nextFloat();
            techo = Math.ceil(num1);
            System.out.println("El redondeo al entero mayor es: "+ techo);
        case REDONDEO:
            System.out.println("Ingresa el numero");
            num1 = user_input.nextFloat();
            redondeo = Math.round(num1);
            System.out.println("El redondeo del numero es: " + redondeo);
        case POTENCIA_AL_CUADRADO:
            System.out.println("Ingresa el numero");
            num1 = user_input.nextFloat();
            potencia2 = Math.pow(num1,2);
            System.out.println("La potencia al cuadrado del numero es:"+ potencia2);
        case POTENCIA_AL_CUBO:
            System.out.println("Ingresa el numero");
            num1 = user_input.nextFloat();
            potencia3 = Math.pow(num1,3);
            System.out.println("La potencia al cubo del numero es: "+potencia3);
        case POTENCIA_A_LA_N:
            System.out.println("Ingresa el primer numero: ");
            num1 = user_input.nextFloat();
            System.out.println("Ingresa el segundo numero");
            num2 = user_input.nextFloat();
            potencian = Math.pow(num1, num2);
            System.out.println("La potencia del numero es: "+ potencian);
        case RAIZ_CUADRADA:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            raiz2 = Math.sqrt(num1);
            System.out.println("La raiz cuadrada del numero es: "+ raiz2);
        case RAIZ_CUBICA:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            raiz3 = Math.pow(num1, 1.0/3.0);
            System.out.println("La raiz cubica del numero es:"+ raiz3);
        case RAIZ_N:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            System.out.println("Ingresa el segundo numero: ");
            num2 = user_input.nextFloat();
            raizn = Math.pow(num1, 1.0/num2);
            System.out.println("La raiz del numero es: "+ raizn);
        case SENO:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            seno = Math.sin(num1);
            System.out.println("El seno del numero es: "+ seno);
        case COSENO:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            coseno = Math.cos(num1);
            System.out.println("El coseno del numero es: "+coseno);
        case TANGENTE:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            tan = Math.tan(num1);
            System.out.println("La tangente del numero es: "+tan);
        case FACTORIAL:
            System.out.println("Ingresa el numero: ");
            num1 = user_input.nextFloat();
            fasct = 1;
            for(int i = 1; i<=num1; i++){
                fasct *= i;
            }
            System.out.println("El factorial del numero es: "+fasct);
        }

    }
}


