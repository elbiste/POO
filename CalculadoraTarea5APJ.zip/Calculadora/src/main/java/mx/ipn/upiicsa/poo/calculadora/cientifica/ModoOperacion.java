package mx.ipn.upiicsa.poo.calculadora.cientifica;

public enum ModoOperacion {
    TERMINAL("Perimetros", "-p"),
    MENU("Menu", "-m");


    private String nombre;
    private String acronimo;


    private ModoOperacion(String nombre, String acronimo){
        this.nombre= nombre;
        this.acronimo= acronimo;
    }
    public String getNombre(){
        return nombre;
    }
    public String getAcronimo(){
        return acronimo;
    }
}
