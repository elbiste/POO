package mx.ipn.upiicsa.poo.calculadora;

public enum CalculadoraOperaciones {

    SUMA(1,"-s", "Suma"),
    RESTA(2,"-r", "Resta"),
    MULTIPLICACION(3,"-m","Multiplicacion"),
    DIVISION(4,"-d","Division"),
    PORCENTAJE(5, "-p", "Porcentaje");


    private int id;
    private String opc;
    private String nombre;

    private CalculadoraOperaciones(int Id, String opc, String nombre){
        this.id = id;
        this.opc = opc;
        this.nombre = nombre;
    }

}
