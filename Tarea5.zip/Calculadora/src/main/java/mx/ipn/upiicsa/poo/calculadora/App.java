package mx.ipn.upiicsa.poo.calculadora;
/*Realizado por Alondra Palestina

 */

import java.util.Scanner;
import java.math.MathContext;


public class App {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        double suma, resta, multiplicacion, division, porcentaje, num1, num2;
        CalculadoraOperaciones calculadoraOperaciones = CalculadoraOperaciones.SUMA;

            switch (calculadoraOperaciones){
                case SUMA:
                    System.out.println("Ingresa el primer numero: ");
                    num1 = user_input.nextFloat();
                    System.out.println("Ingresa el segundo numero: ");
                    num2= user_input.nextFloat();
                    suma= num1+ num2;
                    System.out.println("El resultado de la suma es: "+ suma);
                case RESTA:
                    System.out.println("Ingresa el primer numero: ");
                    num1 = user_input.nextFloat();
                    System.out.println("Ingresa el segundo numero: ");
                    num2= user_input.nextFloat();
                    resta= num1- num2;
                    System.out.println("El resultado de la resta es: "+ resta);
                case MULTIPLICACION:
                    System.out.println("Ingresa el primer numero: ");
                    num1 = user_input.nextFloat();
                    System.out.println("Ingresa el segundo numero: ");
                    num2= user_input.nextFloat();
                    multiplicacion= num1* num2;
                    System.out.println("El resultado de la multiplicacion es: "+ multiplicacion);
                case DIVISION:
                    System.out.println("Ingresa el primer numero: ");
                    num1 = user_input.nextFloat();
                    System.out.println("Ingresa el segundo numero: ");
                    num2= user_input.nextFloat();
                    division= num1/ num2;
                    System.out.println("El resultado de la division es: "+ division);
                case PORCENTAJE:
                    System.out.println("Ingresa el primer numero: ");
                    num1 = user_input.nextFloat();
                    System.out.println("Ingresa el segundo numero: ");
                    num2= user_input.nextFloat();
                    porcentaje= (num1/100)*num2;
                    System.out.println("El resultado del porcentaje es: "+ porcentaje);

            }
        }
    }
