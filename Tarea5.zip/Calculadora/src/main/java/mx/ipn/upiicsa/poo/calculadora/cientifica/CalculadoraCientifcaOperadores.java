package mx.ipn.upiicsa.poo.calculadora.cientifica;
import mx.ipn.upiicsa.poo.calculadora.cientifica.CalculadoraCinetifica;

public enum CalculadoraCientifcaOperadores {

    TECHO(1,"-t","Techo"),
    PISO(2, "-pi", "Piso"),
    REDONDEO(3,"-re", "Redondeo" ),
    POTENCIA_AL_CUADRADO(4, "-x^2", "Potencia al Cuadrado"),
    POTENCIA_AL_CUBO(5, "x^3", "Potencia al cubo"),
    POTENCIA_A_LA_N(6, "X^n", "Potencia a la n"),
    RAIZ_CUADRADA(7,"x_2", "Raiz cuadrada"),
    RAIZ_CUBICA(8, "x_3", "Raiz cubica"),
    RAIZ_N(9, "x_n", "Raiz n"),
    SENO(10, "sin", "Seno"),
    COSENO(11, "cos", "Coseno"),
    TANGENTE(12, "tan", "Tngente"),
    FACTORIAL(13, "x!", "Factorial");


    private int id;
    private String opc;
    private String nombre;

    private CalculadoraCientifcaOperadores(int Id, String opc, String nombre){
        this.id = id;
        this.opc = opc;
        this.nombre = nombre;
    }

}
